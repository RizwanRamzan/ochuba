export const footerTabs=[
    {
        title:"AVAILABLE ON",
        subTitle:[
            {
                name:""
            }
        ]
        
    }
]