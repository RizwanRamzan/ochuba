export { default as Logo } from "./logo.png"
export { default as Ranking } from "./market1.svg"
export { default as Ranking1 } from "./ranking.svg"
export { default as Commiunty } from "./commiunty.svg"
export { default as Profile } from "./download.png"
export { default as Profileeee } from "./download.png"
export { default as TradingHome } from "./trading.jpg"


// Icons


export { default as Finance } from "./icons/finance.svg"
export { default as Media } from "./icons/media.svg"
export { default as news } from "./icons/news.svg"
export { default as politics } from "./icons/politics.svg"
export { default as sports } from "./icons/sports.svg"
export { default as Trading } from "./icons/trading.png"
export { default as Filter } from "./icons/icons8-filter-48.png"


// BEt

export { default as Money } from "./icons/Money.png"
export { default as Cup } from "./icons/Cup.png"
export { default as Boll } from "./icons/Boll.png"


export { default as Fiverr } from "./fiverr.svg"
export { default as Timer } from "./timer.webp"


// slider 

export { default as image1 } from "./banners/1.png"
export { default as image2 } from "./banners/2.png"
export { default as image3 } from "./banners/3.png"
export { default as image4 } from "./banners/4.jpg"
export { default as image5 } from "./banners/5.png"





