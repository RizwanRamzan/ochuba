export const DefaultNumber =[
    {
        number:"2000",
    },
    {
        number:"5000",
    },
    {
        number:"10000",
    },
    {
        number:"50000",
    },
    {
        number:"100000",
    },
    

]


export const result= [
    {
        from: "ETH",
        to: "SOL",
        course: "72.89101174"
    },
    {
        from: "ETH",
        to: "JPY",
        course: "251029.85729621"
    },
    {
        from: "ETH",
        to: "ETH",
        course: "1.00000000"
    },
    {
        from: "ETH",
        to: "CPT",
        course: "1678.95295336"
    },
    {
        from: "ETH",
        to: "XMR",
        course: "11.36547054"
    },
    {
        from: "ETH",
        to: "LTC",
        course: "25.18271827"
    },
    {
        from: "ETH",
        to: "TRX",
        course: "18855.21867174"
    },
    {
        from: "ETH",
        to: "BNB",
        course: "7.82966417"
    },
    {
        from: "ETH",
        to: "BCH",
        course: "7.11939728"
    },
    {
        from: "ETH",
        to: "VERSE",
        course: "5266371.79045675"
    },
    {
        from: "ETH",
        to: "ISK",
        course: "230117.51856602"
    },
    {
        from: "ETH",
        to: "DKK",
        course: "11840.25798346"
    },
    {
        from: "ETH",
        to: "MATIC",
        course: "2985.38152193"
    },
    {
        from: "ETH",
        to: "DAI",
        course: "1679.01576533"
    },
    {
        from: "ETH",
        to: "NOK",
        course: "17959.92952326"
    },
    {
        from: "ETH",
        to: "EUR",
        course: "1587.39536731"
    },
    {
        from: "ETH",
        to: "KZT",
        course: "803266.66193143"
    },
    {
        from: "ETH",
        to: "CAD",
        course: "2276.98383267"
    },
    {
        from: "ETH",
        to: "UAH",
        course: "62094.78629604"
    },
    {
        from: "ETH",
        to: "TRY",
        course: "46102.94174228"
    },
    {
        from: "ETH",
        to: "SEK",
        course: "18343.24552503"
    },
    {
        from: "ETH",
        to: "IDR",
        course: "26006086.63816604"
    },
    {
        from: "ETH",
        to: "TMT",
        course: "5865.38659556"
    },
    {
        from: "ETH",
        to: "AMD",
        course: "665482.69790044"
    },
    {
        from: "ETH",
        to: "PHP",
        course: "95122.22632812"
    },
    {
        from: "ETH",
        to: "MYR",
        course: "7883.12067339"
    },
    {
        from: "ETH",
        to: "THB",
        course: "61377.48810106"
    },
    {
        from: "ETH",
        to: "AZN",
        course: "2854.22004069"
    },
    {
        from: "ETH",
        to: "CNY",
        course: "12078.02401558"
    },
    {
        from: "ETH",
        to: "KRW",
        course: "2271280.08733648"
    },
    {
        from: "ETH",
        to: "CGPT",
        course: "42647.22349295"
    },
    {
        from: "ETH",
        to: "DOGE",
        course: "26984.08847814"
    },
    {
        from: "ETH",
        to: "DASH",
        course: "60.49297297"
    },
    {
        from: "ETH",
        to: "USD",
        course: "1677.60273385"
    },
    {
        from: "ETH",
        to: "PLN",
        course: "7335.27771737"
    },
    {
        from: "ETH",
        to: "RUB",
        course: "163128.61344406"
    },
    {
        from: "ETH",
        to: "CHF",
        course: "1535.16009561"
    },
    {
        from: "ETH",
        to: "USDC",
        course: "1677.38032999"
    },
    {
        from: "ETH",
        to: "BTC",
        course: "0.06174050"
    },
    {
        from: "ETH",
        to: "GBP",
        course: "1375.54701199"
    },
    {
        from: "ETH",
        to: "USDT",
        course: "1678.67999999"
    },
    {
        from: "ETH",
        to: "CZK",
        course: "38703.52850726"
    },
    {
        from: "ETH",
        to: "INR",
        course: "139532.86788052"
    },
    {
        from: "ETH",
        to: "VND",
        course: "40810718.36071949"
    },
    {
        from: "ETH",
        to: "UZS",
        course: "20520080.09484233"
    },
    {
        from: "ETH",
        to: "BUSD",
        course: "1678.51215928"
    }
]